package com.gglynvervr.messenger

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF100D16)
private val SurfaceDark = Color(0xFF1D1727)
private val Purple = Color(0xFF9B5DE5)
private val Muted = Color(0xFFB9A9C9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GGTheme { HomeScreen() } }
    }
}

@Composable
private fun GGTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple,
            background = Background,
            surface = SurfaceDark,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

@Composable
private fun HomeScreen() {
    Surface(modifier = Modifier.fillMaxSize(), color = Background) {
        Column(
            modifier = Modifier.fillMaxSize().padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(color = Purple, shape = RoundedCornerShape(16.dp)) {
                    Text("✈", modifier = Modifier.padding(14.dp), color = Color.White, fontSize = 24.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("ggLynvervr", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("Private Messenger", color = Muted, fontSize = 12.sp)
                }
            }
            HorizontalDivider(color = Color(0xFF382B47))
            Text("Sohbetler", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            ChatPlaceholder("TDLib bağlantısı", "Bir sonraki adımda Telegram hesabına bağlanacağız.")
            ChatPlaceholder("Güvenli başlangıç", "API anahtarları uygulama kaynak koduna yazılmıyor.")
            Spacer(Modifier.weight(1f))
            Text(
                "ggLynvervr • v0.1.0",
                modifier = Modifier.align(Alignment.CenterHorizontally),
                color = Muted,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun ChatPlaceholder(title: String, subtitle: String) {
    Surface(color = SurfaceDark, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = Color.White)
            Spacer(Modifier.height(5.dp))
            Text(subtitle, color = Muted, fontSize = 13.sp)
        }
    }
}
