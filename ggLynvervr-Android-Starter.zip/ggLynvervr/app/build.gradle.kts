import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val localProps = Properties()
val localPropsFile = rootProject.file("local.properties")
if (localPropsFile.exists()) localPropsFile.inputStream().use { localProps.load(it) }

fun secret(name: String) = (System.getenv(name) ?: localProps.getProperty(name) ?: "")
    .replace("\\", "\\\\").replace("\"", "\\\"")

android {
    namespace = "com.gglynvervr.messenger"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.gglynvervr.messenger"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
        buildConfigField("int", "TELEGRAM_API_ID", "\${secret("TELEGRAM_API_ID").ifEmpty { "0" }}")
        buildConfigField("String", "TELEGRAM_API_HASH", "\" \${secret("TELEGRAM_API_HASH")}\"".trim())
    }

    buildFeatures { compose = true; buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("io.github.tdlib-android:core:0.1.1")
    implementation("io.github.tdlib-android:ktx:0.1.1")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
